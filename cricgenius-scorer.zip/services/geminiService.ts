import { GoogleGenAI } from "@google/genai";
import { BallEvent, InningsState } from "../types";

const SYSTEM_INSTRUCTION = `You are an energetic and knowledgeable cricket commentator like Harsha Bhogle or Richie Benaud. 
Your task is to generate short, punchy, and context-aware commentary for a single ball event in a cricket match.
Keep the commentary under 2 sentences. Focus on the action.
Style: Professional, exciting, slightly dramatic for boundaries and wickets.
If it's the second innings, occasionally mention the runs needed if it's close.
`;

export const getCommentaryForBall = async (
  ball: BallEvent,
  innings: InningsState
): Promise<string> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      console.warn("Gemini API Key missing");
      return "Excellent shot!";
    }

    const ai = new GoogleGenAI({ apiKey });
    
    // Construct a prompt based on the event
    let eventDescription = `${ball.bowlerName} to ${ball.batterName}. `;
    
    if (ball.isWicket) {
      eventDescription += `WICKET! ${ball.wicketType}. `;
    } else if (ball.extraType !== 'NONE') {
      eventDescription += `${ball.extraType}. `;
    } else if (ball.runs === 4) {
      eventDescription += `FOUR runs. `;
    } else if (ball.runs === 6) {
      eventDescription += `SIX runs! `;
    } else if (ball.runs === 0) {
      eventDescription += `No run. `;
    } else {
      eventDescription += `${ball.runs} run(s). `;
    }

    let context = `Match Status: ${innings.battingTeamName} is ${innings.totalRuns}/${innings.totalWickets} in ${innings.overs}.${innings.balls} overs.`;
    
    if (innings.inningNumber === 2 && innings.target) {
        const runsNeeded = innings.target - innings.totalRuns;
        context += ` Chasing a target of ${innings.target}. Need ${runsNeeded} runs to win.`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Commentate on this: ${eventDescription}\nContext: ${context}`,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        maxOutputTokens: 60,
        thinkingConfig: { thinkingBudget: 0 } // Speed is priority for live scoring
      }
    });

    return response.text || "What a delivery!";
  } catch (error) {
    console.error("Error generating commentary:", error);
    return "The bowler runs in...";
  }
};