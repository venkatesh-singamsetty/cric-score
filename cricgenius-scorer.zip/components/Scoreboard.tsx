import React, { useState } from 'react';
import { InningsState, Player, Bowler } from '../types';

interface ScoreboardProps {
  currentInnings: InningsState;
  previousInnings?: InningsState;
  onClose: () => void;
}

const Scoreboard: React.FC<ScoreboardProps> = ({ currentInnings, previousInnings, onClose }) => {
  const [activeTab, setActiveTab] = useState<'current' | 'previous'>(
    'current'
  );

  const displayInnings = activeTab === 'current' ? currentInnings : previousInnings;

  if (!displayInnings && activeTab === 'previous') {
      setActiveTab('current');
  }

  const BattingTable = ({ players, order }: { players: Record<string, Player>, order: string[] }) => (
    <div className="overflow-x-auto">
      <table className="w-full text-sm text-left text-slate-600">
        <thead className="text-xs text-slate-700 uppercase bg-slate-100">
          <tr>
            <th className="px-4 py-2 rounded-tl-lg">Batter</th>
            <th className="px-4 py-2">Dismissal</th>
            <th className="px-4 py-2 text-right">R</th>
            <th className="px-4 py-2 text-right">B</th>
            <th className="px-4 py-2 text-right">4s</th>
            <th className="px-4 py-2 text-right rounded-tr-lg">6s</th>
            <th className="px-4 py-2 text-right">SR</th>
          </tr>
        </thead>
        <tbody>
          {order.map((id) => {
            const player = players[id];
            // Only show players who have batted (faced balls or out) or are currently batting
            if (player.ballsFaced === 0 && !player.isOut && id !== displayInnings?.strikerId && id !== displayInnings?.nonStrikerId) {
                return null;
            }
            const isStriker = id === displayInnings?.strikerId;
            const isNonStriker = id === displayInnings?.nonStrikerId;
            const highlight = (activeTab === 'current' && (isStriker || isNonStriker));
            const sr = player.ballsFaced > 0 ? ((player.runs / player.ballsFaced) * 100).toFixed(1) : '0.0';

            return (
              <tr key={id} className={`border-b ${highlight ? 'bg-blue-50' : 'bg-white'}`}>
                <td className="px-4 py-2 font-medium text-slate-900">
                  {player.name} {highlight && '*'}
                </td>
                <td className="px-4 py-2 text-xs text-slate-500">
                  {player.isOut ? (
                      <span className="text-red-600 font-medium">
                          {player.wicketType?.toLowerCase().replace('_', ' ')} b {player.wicketBy}
                      </span>
                  ) : (
                      <span className="text-slate-400">not out</span>
                  )}
                </td>
                <td className="px-4 py-2 text-right font-bold text-slate-800">{player.runs}</td>
                <td className="px-4 py-2 text-right">{player.ballsFaced}</td>
                <td className="px-4 py-2 text-right">{player.fours}</td>
                <td className="px-4 py-2 text-right">{player.sixes}</td>
                <td className="px-4 py-2 text-right">{sr}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );

  const BowlingTable = ({ bowlers, order }: { bowlers: Record<string, Bowler>, order: string[] }) => (
    <div className="overflow-x-auto mt-4">
      <table className="w-full text-sm text-left text-slate-600">
        <thead className="text-xs text-slate-700 uppercase bg-slate-100">
          <tr>
            <th className="px-4 py-2 rounded-tl-lg">Bowler</th>
            <th className="px-4 py-2 text-right">O</th>
            <th className="px-4 py-2 text-right">M</th>
            <th className="px-4 py-2 text-right">R</th>
            <th className="px-4 py-2 text-right">W</th>
            <th className="px-4 py-2 text-right rounded-tr-lg">Econ</th>
          </tr>
        </thead>
        <tbody>
          {order.map((id) => {
            const bowler = bowlers[id];
            if (bowler.overs === 0 && activeTab === 'previous') return null; // Hide unused bowlers in past innings
            if (bowler.overs === 0 && id !== displayInnings?.currentBowlerId) return null;

            const econ = bowler.overs > 0 ? (bowler.runsConceded / bowler.overs).toFixed(1) : '-';
            const isCurrent = activeTab === 'current' && id === displayInnings?.currentBowlerId;

            return (
              <tr key={id} className={`border-b ${isCurrent ? 'bg-green-50' : 'bg-white'}`}>
                <td className="px-4 py-2 font-medium text-slate-900">{bowler.name}</td>
                <td className="px-4 py-2 text-right">{bowler.overs}</td>
                <td className="px-4 py-2 text-right">{bowler.maidens}</td>
                <td className="px-4 py-2 text-right font-bold">{bowler.runsConceded}</td>
                <td className="px-4 py-2 text-right font-bold text-blue-600">{bowler.wickets}</td>
                <td className="px-4 py-2 text-right">{econ}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="bg-slate-900 text-white p-4 flex justify-between items-center shrink-0">
          <h2 className="text-xl font-bold">Full Scorecard</h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-full transition">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
             </svg>
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-200 shrink-0">
          {previousInnings && (
             <button 
                onClick={() => setActiveTab('previous')}
                className={`flex-1 py-3 text-sm font-bold uppercase tracking-wide transition-colors ${activeTab === 'previous' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
             >
                {previousInnings.battingTeamName} (1st Innings)
             </button>
          )}
          <button 
             onClick={() => setActiveTab('current')}
             className={`flex-1 py-3 text-sm font-bold uppercase tracking-wide transition-colors ${activeTab === 'current' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
          >
             {currentInnings.battingTeamName} ({currentInnings.inningNumber === 2 ? '2nd' : '1st'} Innings)
          </button>
        </div>

        {/* Content */}
        {displayInnings ? (
            <div className="p-6 overflow-y-auto custom-scrollbar">
                <div className="mb-6">
                    <div className="flex justify-between items-end mb-2">
                        <h3 className="text-lg font-bold text-slate-800">Batting</h3>
                        <span className="text-2xl font-bold text-slate-900">{displayInnings.totalRuns}/{displayInnings.totalWickets} <span className="text-sm font-normal text-slate-500">({displayInnings.overs}.{displayInnings.balls} ov)</span></span>
                    </div>
                    <BattingTable players={displayInnings.players} order={displayInnings.battingOrder} />
                </div>

                <div>
                    <h3 className="text-lg font-bold text-slate-800 mb-2">Bowling</h3>
                    <BowlingTable bowlers={displayInnings.bowlers} order={displayInnings.bowlingOrder} />
                </div>
                
                <div className="mt-6 p-4 bg-slate-50 rounded-lg text-sm text-slate-600">
                     <strong>Extras:</strong> {displayInnings.allBalls.filter(b => b.isExtra).length} 
                     (w {displayInnings.allBalls.filter(b => b.extraType === 'WIDE').length}, 
                      nb {displayInnings.allBalls.filter(b => b.extraType === 'NO_BALL').length}, 
                      lb {displayInnings.allBalls.filter(b => b.extraType === 'LEG_BYE').length}, 
                      b {displayInnings.allBalls.filter(b => b.extraType === 'BYE').length})
                </div>
            </div>
        ) : (
            <div className="p-10 text-center text-slate-500">No data available</div>
        )}
      </div>
    </div>
  );
};

export default Scoreboard;